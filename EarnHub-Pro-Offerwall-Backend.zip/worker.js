export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Authorization, Content-Type"
    };
    const reply = (body, status=200, json=false) => new Response(body, {
      status, headers: {...cors, "Content-Type": json ? "application/json; charset=utf-8" : "text/plain; charset=utf-8"}
    });
    if (request.method === "OPTIONS") return new Response(null, {status:204, headers:cors});
    const url = new URL(request.url);

    async function param(name) {
      if (url.searchParams.has(name)) return url.searchParams.get(name);
      if (request.method !== "POST") return null;
      const ct = request.headers.get("content-type") || "";
      if (ct.includes("application/json")) {
        const j = await request.clone().json().catch(()=>({}));
        return j[name] == null ? null : String(j[name]);
      }
      const f = await request.clone().formData().catch(()=>null);
      return f && f.has(name) ? String(f.get(name)) : null;
    }
    async function md5(s) {
      const d = await crypto.subtle.digest("MD5", new TextEncoder().encode(s));
      return [...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,"0")).join("");
    }
    function equal(a,b) {
      if (!a || !b || a.length !== b.length) return false;
      let n=0; for(let i=0;i<a.length;i++) n |= a.charCodeAt(i)^b.charCodeAt(i);
      return n===0;
    }

    if (url.pathname === "/health") return reply("EarnHub Offerwall Worker is running");

    if (url.pathname === "/balance" && request.method === "GET") {
      if (!env.DB || !env.FIREBASE_API_KEY) return reply("Worker setup incomplete",500);
      const token = (request.headers.get("Authorization") || "").match(/^Bearer\s+(.+)$/i)?.[1];
      if (!token) return reply("Unauthorized",401);
      const check = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(env.FIREBASE_API_KEY)}`, {
        method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({idToken:token})
      });
      if (!check.ok) return reply("Unauthorized",401);
      const data = await check.json().catch(()=>({}));
      const uid = data?.users?.[0]?.localId;
      if (!uid) return reply("Unauthorized",401);
      const row = await env.DB.prepare("SELECT points FROM offerwall_balances WHERE uid = ?").bind(uid).first();
      return reply(JSON.stringify({points:Number(row?.points || 0)}),200,true);
    }

    if (url.pathname === "/postback" && ["GET","POST"].includes(request.method)) {
      if (!env.DB || !env.OFFERWALL_SECRET) return reply("Worker setup incomplete",500);
      const subId = await param("subId"), transId = await param("transId");
      const reward = await param("reward"), signature = (await param("signature") || "").toLowerCase();
      const status = await param("status") || "1", debug = await param("debug") || "0";
      if (!subId || !transId || !reward || !signature) return reply("Missing parameters",400);
      if (!/^[a-zA-Z0-9_-]{1,180}$/.test(subId) || !/^[a-zA-Z0-9._:-]{1,180}$/.test(transId)) return reply("Invalid ID",400);
      if (!/^\d+(\.\d+)?$/.test(reward) || !["1","2"].includes(status)) return reply("Invalid reward/status",400);
      const secret = await env.OFFERWALL_SECRET.get();
      const expected = await md5(subId + transId + reward + secret);
      if (!equal(expected,signature)) return reply("Invalid signature",403);
      if (debug === "1") return reply("ok");
      const amount = Number(reward);
      if (!Number.isFinite(amount) || amount <= 0 || amount > 100000000) return reply("Invalid amount",400);
      const delta = Math.round(amount * (status === "2" ? -1 : 1));
      await env.DB.batch([
        env.DB.prepare("INSERT OR IGNORE INTO offerwall_transactions (trans_id, uid, reward, status, created_at) VALUES (?, ?, ?, ?, ?)")
          .bind(transId,subId,delta,status,new Date().toISOString()),
        env.DB.prepare(`INSERT INTO offerwall_balances (uid, points)
          SELECT ?, ? WHERE changes() = 1
          ON CONFLICT(uid) DO UPDATE SET points = offerwall_balances.points + excluded.points`)
          .bind(subId,delta)
      ]);
      return reply("ok");
    }
    return reply("Not found",404);
  }
};
