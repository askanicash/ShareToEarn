CREATE TABLE IF NOT EXISTS offerwall_balances (
  uid TEXT PRIMARY KEY,
  points INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS offerwall_transactions (
  trans_id TEXT PRIMARY KEY,
  uid TEXT NOT NULL,
  reward INTEGER NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_offerwall_transactions_uid ON offerwall_transactions(uid);
