EarnHub Pro — OfferwallMedia backend starter

Files:
- worker.js: validates OfferwallMedia S2S signature, ignores duplicate transaction IDs, credits a D1 Offerwall balance, and provides an authenticated /balance endpoint.
- schema.sql: required D1 tables.

IMPORTANT: These files are not live until configured and deployed. Your existing HTML uses localStorage for visible points, so it still needs to be connected to /balance before this is a complete website integration. Do not enable real withdrawals until all balances and deductions are server-side.

Cloudflare setup:
1. Create a D1 database named earnhub-offerwall-db.
2. Run schema.sql in that database's SQL console.
3. Open earnhub-rewards > Settings > Bindings and add a D1 database binding named DB connected to that database.
4. Bind the Secret Store secret to this Worker with the binding name OFFERWALL_SECRET. It must point to your OfferwallMedia website Secret Key. Do not put that key in a normal variable or HTML.
5. Add a normal text variable named FIREBASE_API_KEY with the Firebase Web API key from your existing HTML config.
6. Replace worker.js code in the Worker editor and deploy.
7. Test https://YOUR-WORKER-URL/health. It should say "EarnHub Offerwall Worker is running".
8. Set OfferwallMedia's S2S postback URL to https://YOUR-WORKER-URL/postback.
9. Make sure the offerwall uses each logged-in user's real Firebase UID, not a fixed user123.

OfferwallMedia documents the signature as md5(subId + transId + reward + secretKey), expects "ok" in response, and sends status=1 for credit and status=2 for chargeback. Test callbacks (debug=1) are verified but not credited.

This backend stores Offerwall rewards in D1. It does not yet change Firebase Firestore points or make the existing localStorage withdrawal flow secure.
